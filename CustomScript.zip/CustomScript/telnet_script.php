<?php
$fp=fsockopen("127.0.0.1",80);

if (!$fp) {
    echo "$errstr ($errno)<br />\n";
} else {
	 $out = "GET http://localhost/CustomScript/ftp_file_listing.php HTTP/1.1\r\n";
    $out .= "Host: localhost\r\n";
    $out .= "Connection: Close\r\n\r\n";

    fwrite($fp, $out);
    while (!feof($fp)) {
        echo fgets($fp, 128);
    }
    fclose($fp);
}