<?php
set_time_limit (0);
$address = '127.0.0.1';
$port = 8047;
// Create a TCP Stream socket
$sock = socket_create(AF_INET, SOCK_STREAM, 0); // 0 for  SQL_TCP
// Bind the socket to an address/port
socket_bind($sock, 0, $port) or die('Could not bind to address');  //0 for localhost
// Start listening for connections
socket_listen($sock);
//loop and listen
while (true) {
/* Accept incoming  requests and handle them as child processes */
$client =  socket_accept($sock);
// Read the input  from the client – 1024000 bytes
$input =  socket_read($client, 1024000);
// Strip all white  spaces from input
$output =  preg_replace("[ \t\n\r]","",$input)."\0";
$i  = 1;
if($output > 0 ){
	mkdir("testzip");

	while($i <= $output){
		$myfile = fopen("testzip/testfile".$i.".txt", "w+") or die("Unable to open file!");
		$txt = "Test data\n";
		fwrite($myfile, $txt);
		fclose($myfile);
		$i++;
	}
	$zip = new ZipArchive();
	$DelFilePath = time().".zip";
	
	

	if ($zip->open($_SERVER['DOCUMENT_ROOT']."/CustomScript/".$DelFilePath, ZIPARCHIVE::CREATE) != TRUE) {
        die ("Could not open archive");
	}
	$directory = "testzip";
	 $a_filesFolders = dirToArray( $directory );
	 
	
		  foreach($a_filesFolders as $object) {
		  	 $fileName = $object -> getFilename();
                $pathName = $object -> getPathname();
                if(is_dir( $pathName )){ /*<-- I put on first position*/
                    $pos = strpos($zipProductPath , "/tmp/") + 5;
                    $fileDestination = substr($pathName, $pos);
                    $zip->addEmptyDir($fileDestination);
                }else if(file_exists($pathName)) {
                    $pos = strpos($zipProductPath , "/tmp/") + 5;
                    $fileDestination = substr($pathName, $pos);
                    $zip->addFile($pathName,$fileDestination);
                }
		  }
    $zip->close();
    	
     if(file_exists($DelFilePath)){
                    
                   // header('Content-type: application/zip');
                    //header('Content-Disposition: attachment; filename="'.$DelFilePath.'"');
                    //readfile($DelFilePath);
     									$send = readfile($DelFilePath);
     									$filesize = filesize($DelFilePath);
                     	$outputfinal  = 'HTTP/1.0 200 OK\r\n';
      							 	$outputfinal .= "Content-type: application/zip\r\n";
								      $outputfinal .= "Content-Length: ".$filesize."\r\n";
								      $outputfinal .= 'Content-Disposition: attachment; filename="'.$DelFilePath.'"\r\n';
								      $outputfinal .= "Accept-Ranges: bytes\r\n";
								      $outputfinal .= "Cache-Control: private\n\n";
								      $outputfinal .= $send;
								      $outputfinal .= "Pragma: private\n\n";
								      $outputfinal .= "Content-Transfer-Encoding: binary";
      								$outputfinal .= "Connection: Keep-Alive\r\n";
                    
                }

    
}

}

socket_write($client,$outputfinal);
socket_close($client);
// Close the master sockets
socket_close($sock);


function dirToArray($dir_path) {
    $result = array();
    $path = realpath($dir_path);
    $objects = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path), \RecursiveIteratorIterator::SELF_FIRST);
    foreach($objects as $name => $object) {
        if( $object->getFilename() !== "." && $object->getFilename() !== "..") {
            $result[] = $object;
        }
    }
    return $result;
}