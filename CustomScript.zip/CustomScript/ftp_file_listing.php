<?php
                     
$ftp_server = "localhost";
$ftp_user = "hemant";
$ftp_pass = "";

// set up a connection or die
$conn_id = ftp_connect($ftp_server) or die("Couldn't connect to $ftp_server"); 

// try to login
if (@ftp_login($conn_id, $ftp_user, $ftp_pass)) {
    echo "Connected as $ftp_user@$ftp_server\n";
} else {
    echo "Couldn't connect as $ftp_user\n";
}

$buff = ftp_rawlist($conn_id, '/');
// close the connection
ftp_close($conn_id);  
foreach($buff as $key => $val){
	echo $val;
	echo "<br>";
}
?>