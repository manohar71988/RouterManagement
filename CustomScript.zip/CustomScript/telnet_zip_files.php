<?php
$fp=fsockopen("127.0.0.1",8047);

if (!$fp) {
    echo "$errstr ($errno)<br />\n";
} else {
	
	print('Enter the number of files you want to create.'. PHP_EOL);
	fscanf(STDIN, "%d\n", $number);
    fputs($fp, $number);
    while (!feof($fp)) {
        echo fgets($fp, 128);
    }
    fclose($fp);
}