<?php
   $dbhost = 'localhost:3306';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   
   if(! $conn ) {
      die('Could not connect: ' . mysqli_error($conn));
   }

   print('Enter the number of records you want to insert.'. PHP_EOL);
   //echo "\n";
   
   // $line = trim(fgets(STDIN));
    fscanf(STDIN, "%d\n", $number);
    echo "\n";
    print('Enter the router details in this format from line below:- "sapid" "hostname" "loopback" "macaddress"'. PHP_EOL);
    
    
    mysqli_select_db( $conn,'router');
    $i = 0;
    while(true){
    	
    	if($i == $number){
    		print ("You entered all the records as per the limit.Exiting the program.").
    		exit();
    	}
    	fscanf(STDIN, "%s %s %s %s", $sapid,$hostname,$loopback,$macaddress);
    	$createdAt = date('Y-m-d H:i:s');
    	$updatedAt = date('Y-m-d H:i:s');
    	$sql = "INSERT INTO router_details (`sap_id`,`host_name`, `loopback`, `mac_address`,`created_at`,`updated_at`,`deleted_at`) VALUES ( '".$sapid."', '".$hostname."', '".$loopback."', '".$macaddress."','".$createdAt ."','".$updatedAt."','NULL' )";

         
  	 	$retval = mysqli_query(  $conn,$sql );

	    if(! $retval ) {
	      die('Could not enter data: ' . mysqli_error($conn));
	   }

	   echo "Data entered successfully\n";
	   $i++;
    }

     mysqli_close($conn);