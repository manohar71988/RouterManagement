<?php
 
// example4.php
 
// set the HTTP header type to PNG
header("Content-type: image/png"); 
 
// set the width and height of the new image in pixels
$width = 350;
$height = 360;
 
 $img_width = 400;
 $img_height = 400;

 $width1 = 300;
$height1 = 300;
// create a pointer to a new true colour image
$im = ImageCreateTrueColor($width, $height); 
 
 $im1 = ImageCreateTrueColor($width1, $height1); 
// switch on image antialising if it is available
ImageAntiAlias($im, true);
 
// sets background to white
$white = ImageColorAllocate($im, 255, 255, 255); 
ImageFillToBorder($im, 0, 0, $white, $white);

$white1 = ImageColorAllocate($im1, 255, 255, 255); 
ImageFillToBorder($im1, 0, 0, $white1, $white1);
 
// define black and blue colours
$black = ImageColorAllocate($im, 0, 0, 0);
$blue = ImageColorAllocate($im, 0, 0, 255);
 
 $black1 = ImageColorAllocate($im1, 0, 0, 0);

// draw an empty circle
ImageEllipse($im, 180, 200, 250, 250, $black);
 
$rectangle_width = 80;

$rectangle_height = 80;

$r_x = 150;

$r_y = 150;

ImageRectangle($im, $r_x, $r_y, $r_x+$rectangle_width, $r_y+$rectangle_height, $black);
 
  $im = imagerotate($im, 130, 0);

//ImageLine($im, 200, 200, 400, 400, $black);
// send the new PNG image to the browser
ImagePNG($im); 
 ImagePNG($im1);
// destroy the reference pointer to the image in memory to free up resources
ImageDestroy($im); 
 
?>