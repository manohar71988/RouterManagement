<?php
$output = 5;
$i = 1;
if($output > 0 ){
	mkdir("test3");

	while($i <= $output){
		$myfile = fopen("test3/testfile".$i.".txt", "w+") or die("Unable to open file!");
		$txt = "Test data\n";
		fwrite($myfile, $txt);
		fclose($myfile);
		$i++;
	}
	$zip = new ZipArchive();
	$DelFilePath = time().".zip";
	echo $_SERVER['DOCUMENT_ROOT'];
	

	if ($zip->open($_SERVER['DOCUMENT_ROOT']."/CustomScript/".$DelFilePath, ZIPARCHIVE::CREATE) != TRUE) {
        die ("Could not open archive");
	}
	$directory = "test1";
	 $a_filesFolders = dirToArray( $directory );
	 
	
		  foreach($a_filesFolders as $object) {
		  	 $fileName = $object -> getFilename();
                $pathName = $object -> getPathname();
                if(is_dir( $pathName )){ /*<-- I put on first position*/
                    $pos = strpos($zipProductPath , "/tmp/") + 5;
                    $fileDestination = substr($pathName, $pos);
                    $zip->addEmptyDir($fileDestination);
                }else if(file_exists($pathName)) {
                    $pos = strpos($zipProductPath , "/tmp/") + 5;
                    $fileDestination = substr($pathName, $pos);
                    $zip->addFile($pathName,$fileDestination);
                }
		  }
    $zip->close();

     if(file_exists($DelFilePath)){
                    
                    header('Content-type: application/zip');
                    header('Content-Disposition: attachment; filename="'.$DelFilePath.'"');
                    readfile($DelFilePath);
                    
                }

    
}

function dirToArray($dir_path) {
    $result = array();
    $path = realpath($dir_path);
    $objects = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path), \RecursiveIteratorIterator::SELF_FIRST);
    foreach($objects as $name => $object) {
        if( $object->getFilename() !== "." && $object->getFilename() !== "..") {
            $result[] = $object;
        }
    }
    return $result;
}